package tester;

import static utils.HibernateUtils.getSf;

import static java.time.LocalDate.*;

import java.util.List;
import java.util.Scanner;

import org.hibernate.*;

import dao.DepartmentDaoImpl;
import pojos.Department;
import pojos.Employee;


public class DeptEmpTester {

	public static void main(String[] args) {
		DepartmentDaoImpl dao = new DepartmentDaoImpl();
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			boolean exit = false;
			System.out.println("hibernate booted....");
			while (!exit) {
				try {
					System.out.println("************Menu***********");
					System.out.println("1.Create a new department\n" + "2.Hire Emp in a dept\n" + "3.Display employees from a specific dept\n"
							+ "4.Fire employee from a dept\n"
							+ "10.Exit");
					System.out.println("Enter Option:");
					switch (sc.nextInt()) {
					case 1: 
					{
						System.out.println("Enter Dept Details(Name,Location):");
						Department dept = new Department(sc.next(),sc.next());
						for(int i=0;i<3;i++)
						{
							System.out.println("Enter Emp details(name,sal):");
							dept.addEmployee(new Employee(sc.next(),sc.nextDouble()));
						}
						System.out.println(dao.createNewDept(dept));
					}
						break;
					case 2:
					{
						System.out.println("Enter Dept ID: ");
						int deptId = sc.nextInt();
						System.out.println("Enter Hired Employee Details(name,sal): ");
						System.out.println(dao.hireEmp(deptId, new Employee(sc.next(),sc.nextDouble())));
					}
						break;
					case 3:
					{
						System.out.println("Enter Dept Name: ");
						List<Employee> l1=dao.listEmps(sc.next());
						System.out.println(l1);
					}
						break;
					case 4:
					{
						System.out.println("Enter Dept ID and Employee ID:");
						System.out.println(dao.fireEmp(sc.nextInt(), sc.nextInt()));
					}
						break;
					case 5:
						
						break;
					case 6:
						
						break;
					case 10:
					{
						System.out.println("Thanks for using our app!!");
						exit = true;
					}
						break;
					default:
						System.out.println("Invalid Input!!");
						break;
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				sc.nextLine();
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}

	}

}
