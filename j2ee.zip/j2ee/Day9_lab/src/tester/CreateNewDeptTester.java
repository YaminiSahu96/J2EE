package tester;
import static utils.HibernateUtils.*;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

import dao.DepartmentDaoImpl;
import pojos.Department;
import pojos.Employee;

public class CreateNewDeptTester {

	public static void main(String[] args) {
		try(SessionFactory sf = getSf();
				Scanner sc = new Scanner(System.in))
		{
			System.out.println("hibernate booted....");
			System.out.println("Enter Dept Details(Name,Location):");
			Department dept = new Department(sc.next(),sc.next());
			for(int i=0;i<3;i++)
			{
				System.out.println("Enter Emp details(name,sal):");
				dept.addEmployee(new Employee(sc.next(),sc.nextDouble()));
			}
			//invoke Dao layer
			DepartmentDaoImpl dao = new DepartmentDaoImpl();
			System.out.println(dao.createNewDept(dept));
		}
		catch(HibernateException e)
		{
			
		}

	}

}
