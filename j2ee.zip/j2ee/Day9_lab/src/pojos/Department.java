package pojos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

@Entity
@Table(name="departments")
public class Department extends IdentitySuperClass{
	@Column(length = 20, unique = true)
	private String name;
	@Column(length = 20)
	private String location;
	
	@OneToMany(mappedBy = "dept",cascade = CascadeType.ALL)
	private List<Employee> emps = new ArrayList<>();
	
	public Department() {
		System.out.println("in dept ctor");
	}
	
	public Department(String name, String location) {
		super();
		this.name = name;
		this.location = location;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<Employee> getEmps() {
		return emps;
	}
	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}
	@Override
	public String toString() {
		return "Department [name=" + name + ", location=" + location + ", getId()=" + getId() + "]";
	}
	
	//helper Methods for Adding and removing Employees
	public void addEmployee(Employee e)
	{
		emps.add(e);					//dept--->emp
		System.out.println(e.getDept());
		e.setDept(this);				//emp---->dept
	}
	
	public void removeEmployee(Employee e)
	{
		emps.remove(e);					//dept--XX-->emp
		e.setDept(null);				//emp--XX-->dept
	}
	
}
