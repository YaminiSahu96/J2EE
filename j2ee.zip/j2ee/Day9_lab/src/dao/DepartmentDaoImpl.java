package dao;

import pojos.Department;
import pojos.Employee;

import org.hibernate.*;
import static utils.HibernateUtils.*;

import java.util.List;

public class DepartmentDaoImpl implements IDepartmentDao {

	@Override
	public String createNewDept(Department d) {
		String msg = "Adding Dept Failed!!";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			// d-->Transient
			hs.save(d); // persistent
			tx.commit();// insert query ---> l1 cache destroyed --> session closed
			msg = "Dept Added Successfully!";
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	@Override
	public String hireEmp(int deptId, Employee emp) {
		String msg = "Employee Not Hired!!";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			Department dept = hs.get(Department.class, deptId);
			if (dept != null) {
				dept.addEmployee(emp);
				msg = "Employee Hired!!";
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	@Override
	public List<Employee> listEmps(String deptName) {
		String jpql = "select d from Department d where name = :nm";
		List<Employee> l1 = null;
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			Department d = hs.createQuery(jpql, Department.class).setParameter("nm", deptName).getSingleResult();
			if (d != null) {
				System.out.println();
				l1 = d.getEmps();
			}
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			throw new RuntimeException("err in listEmp", e);
		}
		return l1;
	}

	@Override
	public String fireEmp(int deptId, int empId) {
		String msg = "Employee not fired!!";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try 
		{
			//Persistent data
			Department d = hs.get(Department.class, deptId);
			Employee emp =hs.get(Employee.class, empId);
			if(emp.getDept().getId().equals(deptId))
			{
				d.removeEmployee(emp);
				hs.delete(emp);
				msg = "Employee fired successfully!!";
			}
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

}
