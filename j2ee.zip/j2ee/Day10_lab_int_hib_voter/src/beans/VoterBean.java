package beans;

import dao.VotingDaoImpl;

import pojos.Voters;

public class VoterBean {

	private String email,password,password2;		//Properties of this JavaBean Should match with the Request Parameter name 

	private VotingDaoImpl dao;
	//results
	private Voters voter;
	private String msg;

	public VoterBean() 
	{
		dao = new VotingDaoImpl();
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public String getEmail() {
		return email;
	}
	
	public Voters getVoter() {
		return voter;
	}

	public String getMsg() {
		return msg;
	}
	
	public String validateVoter()			//returning Dynamic NAVIGATIONAL Outcome
	{
		System.out.println("Validate Voter "+email+" "+password);
		try 
		{
			voter = dao.authenticateVoter(email, password);
		}
		catch(RuntimeException e)
		{
			System.out.println("Err "+e);
			msg = "Invalid Login details!! Please Retry";
			return "login";										//Not using login.jsp so as the technology migration is easy(eg-from jsp to angular)
		}
		msg = "Success";
		if(voter.getAdminRights().equals("admin"))
			return "voting_analysis";						
		if(voter.isStatus())
			return "status";								//Aready voted
		return "list_details";								//Not Voted
	}
	
	public String updateStatus()
	{
		return (dao.updateStatus(voter) != null) ? "Voted Sccessfully!!":"unable to Update Status";
	}
	
	public String registerVoter()
	{
		if(!password.equals(password2))
		{
			msg="Passwords Don't Match,Please retry!!";
			return "register";
		}
		msg = dao.registerVoter(new Voters( email, password, false, "voter"));
		if(msg == null)
		{
			msg="Email already in use!!";
			return "reg_result";
		}
		return "reg_result";
	}
	
}
