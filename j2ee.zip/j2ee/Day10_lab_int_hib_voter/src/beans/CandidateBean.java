package beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import dao.CandidateDaoImpl;
import pojos.Analysis;
import pojos.Candidate;

public class CandidateBean {

	private int canId;
	private CandidateDaoImpl dao;
	
	public void setCanId(int canId) {
		this.canId = canId;
	}


	public CandidateBean()
	{
		System.out.println("in Candidate Bean ctor");
		dao = new CandidateDaoImpl();					//dependent object(Bean) creating its dependency(DAO) --> TIGHT COUPLING
	}
	
	public List<Candidate> getCandidateList()
	{
		return dao.getCandidateList();
	}
	
	public List<Candidate> getTopTwoCandidates() throws Exception
	{
		List<Candidate> candy = new ArrayList<>();
		List<Candidate> candidates = getCandidateList();
		
		Collections.sort(candidates, Collections.reverseOrder(new Comparator<Candidate>() {
		
			@Override
			public int compare(Candidate c1, Candidate c2)
			{
				return ((Long)c1.getVotes()).compareTo(c2.getVotes());
			}
		}));
		
		
		candy.add(candidates.get(0));
		candy.add(candidates.get(1));
		return candy;
	}
	public List<Analysis> getVotesPartyWise() throws Exception
	{
		return dao.getVotesPartyWise();
	}
	
	
	
	public String updateVotes() throws Exception
	{
		String msg = dao.updateVotes(canId);
		return (msg != null) ? msg : "unable to Increment votes";
	}
	
}
