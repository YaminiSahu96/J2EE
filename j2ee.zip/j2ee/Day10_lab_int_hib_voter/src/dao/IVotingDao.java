package dao;

import pojos.Voters;

public interface IVotingDao {

	Voters authenticateVoter(String em,String pass);
	
	String updateStatus(Voters v);	//detached voter ref -- kept in Java Bean (HttpSession)
	
	String registerVoter(Voters v);
}
