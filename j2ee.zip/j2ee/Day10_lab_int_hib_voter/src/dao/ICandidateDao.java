package dao;

import java.util.List;

import pojos.Analysis;
import pojos.Candidate;

public interface ICandidateDao {
	
	List<Analysis> getVotesPartyWise() ;
	
	List<Candidate> getCandidateList() ;
	
	String updateVotes(int canId) ;
	
}
