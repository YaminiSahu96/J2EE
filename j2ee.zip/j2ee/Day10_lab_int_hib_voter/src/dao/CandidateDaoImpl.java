package dao;

import java.util.ArrayList;
import java.util.List;
import static utils.HibernateUtils.*;

import pojos.Analysis;
import pojos.Candidate;
import org.hibernate.*;


public class CandidateDaoImpl implements ICandidateDao {

	@Override
	public List<Candidate> getCandidateList() {
		String jpql = "select c from Candidate c";
		List<Candidate> l1 = null;
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql,Candidate.class).getResultList();
			tx.commit();
		}catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return l1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Analysis> getVotesPartyWise()  {
		//List<Candidate> l1 = new ArrayList<>();
		List<Analysis> l1 = null;
		//String jpql = "select c.party, sum(c.votes) from Candidate c group by c.party order by sum(c.votes)";
		String jpql = "select new pojos.Analysis(c.party, sum(c.votes)) from Candidate c group by c.party order by sum(c.votes) desc";
		//String jpql1 = "select sum(c.votes) from Candidate c group by c.party order by c.party";
		//String jpql2 = "select Distinct(c.party) from Candidate c order by c.party";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql, Analysis.class).getResultList();
			
//			List<Object[]> l4 = hs.createQuery(jpql).getResultList();
//			if(l4 != null)
//			{
//				for(Object[] o: l4)
//				{
//					l1.add(new Candidate((String)o[0],(Long)o[1]));
//				}
//			}
			
//			List<Integer> l2 = hs.createQuery(jpql1, Integer.class).getResultList(); 
//			List<String> l3 = hs.createQuery(jpql2, String.class).getResultList();
//			String[] s3 = null;
//			Integer[] s2 = null;
//			if(l2 != null && l3 != null)
//			{
//				s3 = l3.toArray(new String[0]);
//				s2 = l2.toArray(new Integer[0]);
//			}
//			for(int i=0; i<s2.length; i++)
//			{
//				l1.add(new Candidate(s3[i], s2[i]));
//			}
			tx.commit();
		}catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return l1;
	}

	@Override
	public String updateVotes(int canId)  {
		String msg = "Unable to Update Votes!!!";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			Candidate c = hs.get(Candidate.class, canId);
			if(c != null)
			{
				c.setVotes(c.getVotes()+1);
				msg = "Votes Updated Successfully!!";
			}
			tx.commit();
		}catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

}
