package dao;

import pojos.Voters;
import org.hibernate.*;
import static utils.HibernateUtils.*;

public class VotingDaoImpl implements IVotingDao {

	@Override
	public Voters authenticateVoter(String em, String pass) {
		Voters v = null;
		String jpql = "select v from Voters v where v.email = :m and v.password = :p";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			v=hs.createQuery(jpql, Voters.class).
					setParameter("m", em).
					setParameter("p", pass).
					getSingleResult();
			tx.commit();
		}catch(RuntimeException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return v;
	}

	@Override
	public String updateStatus(Voters v) {
		String msg = "Unable to Update Status!!";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			//Re-attach detached POJO 
			hs.update(v);	//v-->Persistent
			v.setStatus(true);
			msg = "Voting Status Updated!!";
			tx.commit();
		}catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

	@Override
	public String registerVoter(Voters v) {
		String msg = null;
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			//Re-attach detached POJO 
			hs.save(v);	//v-->Persistent
			tx.commit();
			msg = "Voter Added Successfully!!";
		}catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return msg;
	}

}
