package pojos;
import javax.persistence.*;

@Entity
@Table(name="candidates")
public class Candidate {

	private Integer id;
	private String name,party;
	private Long votes;
	
	

	public Candidate() {
		super();
	}


	public Candidate(String party, Long votesPartyWise) {
		super();
		this.party = party;
		this.votes = votesPartyWise;
	}


	public Candidate(Integer id, String name, String party, Long votes) {
		super();
		this.id = id;
		this.name = name;
		this.party = party;
		this.votes = votes;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	@Column(name="political_party")
	public String getParty() {
		return party;
	}


	public void setParty(String party) {
		this.party = party;
	}


	public Long getVotes() {
		return votes;
	}


	public void setVotes(Long votes) {
		this.votes = votes;
	}
	
	
	
}
