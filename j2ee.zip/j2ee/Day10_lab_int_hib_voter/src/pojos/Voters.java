package pojos;
import javax.persistence.*;

@Entity
@Table(name="voters")
public class Voters {

	private Integer id;
	private String email,password;
	private boolean status;
	private String adminRights;
	
	
	
	public Voters() {
		System.out.println("in default ctor of Voters");
	}

	public Voters(Integer id, String email, boolean status,String adminRights) {
		super();
		this.id = id;
		this.email = email;
		this.status = status;
		this.adminRights = adminRights;
	}
	
	public Voters(String email, String password, boolean status, String adminRights) {
		this.email = email;
		this.password = password;
		this.status = status;
		this.adminRights = adminRights;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Column(name="admin_rights")	
	public String getAdminRights() {
		return adminRights;
	}
	public void setAdminRights(String adminRights) {
		this.adminRights = adminRights;
	}
	@Override
	public String toString() {
		return "Voters [id=" + id + ", email=" + email + ", status=" + status + "]";
	}
}
