package pojos;

import java.time.LocalDate;
import javax.persistence.*;

@Entity
@Table(name = "vendor")
public class Vendor {

	private Long id;
	private String name,email,password,city,phoneNo;
	private double regAmt;
	private LocalDate regDate;
	
	public Vendor() {
		
		System.out.println("in vendor ctor");
	}

	public Vendor(String name, String email, String password, String city, String phoneNo, double regAmt,
			LocalDate regDate) {
		
		this.name = name;
		this.email = email;
		this.password = password;
		this.city = city;
		this.phoneNo = phoneNo;
		this.regAmt = regAmt;
		this.regDate = regDate;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(length = 30)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(unique = true, length = 30)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(length = 20)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(length = 20)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name="phone_no",length = 10, unique=true)
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Column(name="reg_amt")
	public double getRegAmt() {
		return regAmt;
	}

	public void setRegAmt(double regAmt) {
		this.regAmt = regAmt;
	}

	@Column(name="reg_date")
	public LocalDate getRegDate() {
		return regDate;
	}

	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "Vendor [id=" + id + ", name=" + name + ", email=" + email + ", city=" + city + ", phoneNo=" + phoneNo
				+ ", regAmt=" + regAmt + ", regDate=" + regDate + "]\n";
	}
	
	
	
}
