package tester;
import static utils.HibernateUtils.*;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;

public class TestHibernate {

	public static void main(String[] args) {
		try(SessionFactory sf = getSf())
		{
			System.out.println("hibernate booted....");
			
		}
		catch(HibernateException e)
		{
			
		}

	}

}
