package tester;

import static utils.HibernateUtils.getSf;

import static java.time.LocalDate.*;
import java.util.Scanner;

import org.hibernate.*;

import dao.VendorDaoImpl;
import pojos.Vendor;

public class VendorTester {

	public static void main(String[] args) {

		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			VendorDaoImpl dao = new VendorDaoImpl();
			boolean exit = false;
			System.out.println("hibernate booted....");
			while (!exit) {
				System.out.println("************Menu***********");
				System.out.println("1.Register Vendor\n" + "2.Get a Vendor (using Vendor ID)\n" + "3.List all vendor details\n"
						+ "4.List all vendors from specified city after specific reg date\n"
						+ "5.Update Vendor's City and Phone Num\n"
						+ "6.Un subscribe vendor"
						+ "10.Exit");
				System.out.println("Enter Option:");
				switch (sc.nextInt()) {
				case 1: {
					System.out.println(
							"Enter Vendor Details ( name,  email,  password,  city,  phoneNo,  regAmt, regDate)");
					System.out.println(dao.registerVendor(new Vendor(sc.next(), sc.next(), sc.next(), sc.next(),
							sc.next(), sc.nextDouble(), parse(sc.next()))));
				}
					break;
				case 2:
					System.out.println("Enter Vendor ID: ");
					Vendor v = dao.getDetails(sc.nextLong());
					System.out.println(v);
					break;
				case 3:
					System.out.println(dao.getAllVendors());
					break;
				case 4:
					System.out.println("Enter Vendor City & reg_date");
					System.out.println(dao.getSelectedVendors(sc.next(), parse(sc.next()))); 
					break;
				case 5:
					System.out.println("Enter Vendor ID, new City and new Phone number to update:");
					System.out.println(dao.updateVendorDetails(sc.nextLong(), sc.next(), sc.next()));
					break;
				case 6:
					System.out.println("Enter Vendor Id to unsubscribe:");
					System.out.println(dao.deleteVendorDetails(sc.nextLong()));
					break;
				case 10:
				{
					System.out.println("Thanks for using our app!!");
					exit = true;
				}
					break;
				default:
					System.out.println("Invalid Input!!");
					break;
				}
				sc.nextLine();
			}
		} catch (HibernateException e) {

		}

	}

}
