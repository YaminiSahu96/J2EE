package dao;

import java.time.LocalDate;
import java.util.List;
import static utils.HibernateUtils.*;
import pojos.Vendor;
import org.hibernate.*;

public class VendorDaoImpl implements IVendorDao 
{

	@Override
	public String registerVendor(Vendor v) {
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		try {
			Long id = (Long) hs.save(v);
			System.out.println(id);
			txn.commit();
		}catch(HibernateException e)
		{
			if(txn != null)
				txn.rollback();
			throw e;
		}
		return "Vendor reg succeeded with ID " + v.getId();
	}

	@Override
	public Vendor getDetails(long id) {
		Vendor v=null;
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		try {
			
			v = hs.get(Vendor.class, id);	//id ---AutoBoxing---> Long -----> Serializable
			txn.commit();
		}catch(HibernateException e)
		{
			if(txn != null)
				txn.rollback();
			throw e;
		}
		return v;
	}

	@Override
	public List<Vendor> getAllVendors() {
		String jpql = "select v from Vendor v";
		List<Vendor> l1 = null;
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		try {
			l1 = hs.createQuery(jpql, Vendor.class).getResultList();
			txn.commit();
		}catch(HibernateException e)
		{
			if(txn != null)
				txn.rollback();
		}
		return l1;
	}

	@Override
	public List<Vendor> getSelectedVendors(String city, LocalDate dt) {
		String jpql = "select v from Vendor v where v.city = :ct and v.regDate > :rdt";
		List<Vendor> l2=null;
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		try {
			l2 = hs.createQuery(jpql, Vendor.class).setParameter("ct", city).setParameter("rdt", dt).getResultList();
			txn.commit();
		}catch(HibernateException e)
		{
			if(txn != null)
				txn.rollback();
		}
		return l2;
	}

	@Override
	public String updateVendorDetails(long vid, String newCity, String newPhone) {
		String jpql = "select v from Vendor v where v.id = :id";
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		try {
			Vendor v = hs.createQuery(jpql, Vendor.class).setParameter("id", vid).getSingleResult();
			v.setCity(newCity);
			v.setPhoneNo(newPhone);
			txn.commit();
		}catch(HibernateException e)
		{
			if(txn != null)
				txn.rollback();
			throw e;
		}
		return "Vendor "+vid+" details updated";
	}

	@Override
	public String deleteVendorDetails(long vid) {
		String jpql = "select v from Vendor v where v.id = :id";
		Session hs = getSf().getCurrentSession();
		Transaction txn = hs.beginTransaction();
		Vendor v = null;
		try {
			 v = hs.createQuery(jpql, Vendor.class).setParameter("id", vid).getSingleResult();
			 hs.delete(v);
			txn.commit();
		}catch(HibernateException e){
			if(txn != null)
				txn.rollback();
		}
		return v+" Un-subscribed Successfully!!";
	}

}
