package dao;

import java.time.LocalDate;
import java.util.List;

import pojos.Vendor;

public interface IVendorDao {

	String registerVendor(Vendor v);
	Vendor getDetails(long id);
	List<Vendor> getAllVendors();
	List<Vendor> getSelectedVendors(String city,LocalDate dt);
	String updateVendorDetails(long vid,String newCity,String newPhone);
	String deleteVendorDetails(long vid);
	
}
