package pages;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.VotingDaoImpl;
import pojos.Candidate;
import pojos.Voters;

/**
 * Servlet implementation class ListServlet
 */
@WebServlet("/list")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter pw = response.getWriter())
		{
			response.setContentType("text/html");
			HttpSession session = request.getSession();
			List<Candidate> candidates = null;
			candidates = ((VotingDaoImpl)session.getAttribute("dao_obj")).getCandidateList();
			Voters v = (Voters) session.getAttribute("voter_obj");
			pw.write("<h3>Welcome, "+v.getEmail()+"("+v.getAdminRights()+") to Voting Desk</h3>");
			pw.write("<form action='status'>");
			for(Candidate c : candidates)
				pw.write("<input type=radio name=cid value="+c.getId()+">"+c.getName()+" ("+c.getParty()+")");
			pw.write("<input type=submit value='Vote'>");
			pw.print("</form>");
		}
		catch (Exception e) 
		{
			throw new ServletException("err in doGet..."+getClass().getName(),e);
		}
		
		
	}

}
