package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.VotingDaoImpl;
import pojos.Candidate;
import pojos.Voters;

/**
 * Servlet implementation class StatusServlet
 */
@WebServlet("/status")
public class StatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{	
			HttpSession session = request.getSession();
			Voters v = (Voters) session.getAttribute("voter_obj");
			VotingDaoImpl vdao = ((VotingDaoImpl)session.getAttribute("dao_obj"));
			//For Admin
			if(v.getAdminRights().equalsIgnoreCase("admin"))
			{
				if(v.isStatus())
					pw.write("<h4>Hello, "+v.getEmail()+"("+v.getAdminRights()+") You have <h3>ALREADY</h3> voted successfully!!</h4>");
				else
				{
					incUpdateVoteStatus(request.getParameter("cid"),v,pw,vdao);
				}
				//Top two Candidate
				pw.write("<table style='background-color: cyan; margin: auto;'>");
				pw.write("<tr>");
				pw.write("<td><---Top 2 candidates List---></td>");
				pw.write("</tr>");
				
				List<Candidate> topTwoCandidates = vdao.getTopTwoCandidate();
				for(Candidate c:topTwoCandidates)
				{
					pw.write("<tr>");
					pw.write("<td>Name: "+c.getName()+"</td>");
					pw.write("<td>Vote Count: "+c.getVotes()+"</td>");
					pw.write("</tr>");
				}
				pw.write("</table>");
				//party vise votes(Analysis)
				pw.write("<table style='background-color: cyan; margin: auto;'>");
				pw.write("<tr>");
				pw.write("<td><---Vote Analysis---></td>");
				pw.write("</tr>");
				
				List<Candidate> votesPartyWise = vdao.getVotesPartyWise();
				for(Candidate c:votesPartyWise)
				{
					pw.write("<tr>");
					pw.write("<td>Political Party: "+c.getParty()+"</td>");
					pw.write("<td>Vote Count: "+c.getVotes()+"</td>");
					pw.write("</tr>");
				}
				pw.write("</table>");
			}
			else
			{
				//For voters
				if(v.isStatus())
				{
					pw.write("<h4>Hello, "+v.getEmail()+"("+v.getAdminRights()+") You have <h3>ALREADY</h3> voted successfully!!</h4>");
					pw.write("<h4><a href='login.html'>LogOut</a></h4>");
				}
				else
				{
					incUpdateVoteStatus(request.getParameter("cid"),v,pw,vdao);
				}
			}
			session.invalidate();
		} 
		catch (Exception e) {
			throw new ServletException("err in doGet..."+getClass().getName(),e);
		}
	}
	
	public void incUpdateVoteStatus(String cid, Voters v, PrintWriter pw,VotingDaoImpl vdao) throws  Exception
	{
		if(cid != null)
		{
			if(vdao.incVotesUpdateStatus(Integer.parseInt(cid), v.getId()) != null)
				pw.write("<h4>Hello, "+v.getEmail()+"("+v.getAdminRights()+") You have voted for "+cid+" successfully!!</h4>");
			else
				pw.write("<h4>Hello, "+v.getEmail()+"("+v.getAdminRights()+") <br>Not able to update!! Sorry for the inconvenience</h4>");
			pw.write("<h4>You are now Signed Out!<br><a href='login.html'>Re-Visit</a></h4>");
		}
		else
		{
			pw.write("<h4>Hello, "+v.getEmail()+"("+v.getAdminRights()+") <br>You have not selected any candidate!!</h4>");
			pw.write("<h4>You are now Signed Out!<br><a href='login.html'>Re-Visit</a></h4>");
		}
	
	}

}
