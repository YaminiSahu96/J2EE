package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.VotingDaoImpl;
import pojos.Voters;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VotingDaoImpl vdao;
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		try {
			vdao = new VotingDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init..."+getClass().getName(),e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() 
	{
		try {
			vdao.cleanUp();
		} catch (Exception e) {
			throw new RuntimeException("err in destroy..."+getClass().getName(),e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		try {
			Voters voter = vdao.authenticateVoter(request.getParameter("em"), request.getParameter("pass"));
			try(PrintWriter pw = response.getWriter())
			{
				if(voter == null)
					pw.print("<h4>Invalid Credentials! Please <a href='login.html'>Retry</a></h4>");
				else 
				{
					HttpSession session = request.getSession();
					session.setAttribute("dao_obj", vdao);
					session.setAttribute("voter_obj", voter);
					for(Enumeration<String> e=session.getAttributeNames();e.hasMoreElements();)
					{
						String attrName = e.nextElement();
						System.out.println("jsessionid="+session.getId()+" NEW session="+session.isNew()+" attrName="+attrName);
					}
					
					if(voter.isStatus())
						response.sendRedirect("status");
					else
						response.sendRedirect("list");
				}
			}
		}catch (Exception e) {
			throw new ServletException("err in doGet..."+getClass().getName(),e);
		}
	}

}
