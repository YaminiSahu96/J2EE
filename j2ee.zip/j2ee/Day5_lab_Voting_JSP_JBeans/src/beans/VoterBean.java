package beans;



import java.util.List;

import dao.VotingDaoImpl;
import pojos.Candidate;
import pojos.Voters;

public class VoterBean {

	private String email,password;		//Properties of this JavaBean Should match with the Request Parameter name 

	private VotingDaoImpl dao;
	
	private Voters voter;
	
	private String msg;
	
	private int canId;

	public VoterBean() throws Exception
	{
			dao = new VotingDaoImpl();
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public Voters getVoter() {
		return voter;
	}
	
	public void setCanId(int canId) {
		this.canId = canId;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public String validateVoter() throws Exception			//returning NAVIGATIONAL Outcome
	{
		voter = dao.authenticateVoter(email, password);
		if(voter == null)
		{
			msg = "Invalid Login details!! Please Retry";
			return "login";									//Not using login.jsp so as the technology migration is easy(eg-from jsp to angular)
		}
		msg = "Success";
		if(voter.getAdminRights().equals("admin"))
			return "admin_page";
		if(voter.isStatus())
			return "status";								//Aready voted
		return "list_details";								//Not Voted
	}
	
	public List<Candidate> getCandidateList() throws Exception
	{
		return dao.getCandidateList();
	}
	
	public String incUpdateVoteStatus() throws Exception
	{
		return (dao.incVotesUpdateStatus(canId,voter.getId()) != null) ? "Voted Sccessfully!!":"";
	}
	
	public List<Candidate> getTopTwoCandidates() throws Exception
	{
		return dao.getTopTwoCandidate();
	}
	public List<Candidate> getVotesPartyWise() throws Exception
	{
		return dao.getVotesPartyWise();
	}
}
