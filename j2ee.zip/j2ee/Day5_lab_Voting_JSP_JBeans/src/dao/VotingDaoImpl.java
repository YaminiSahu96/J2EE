package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojos.Candidate;
import pojos.Voters;
import static utils.DBUtils.*;

public class VotingDaoImpl implements IVotingDao {

	Connection cn;
	PreparedStatement pst1, pst2, pst3, pst4,pst5,pst6;
	
	public VotingDaoImpl() throws ClassNotFoundException, SQLException 
	{
		cn = connectDB();
		pst1 = cn.prepareStatement("select id,email,status,admin_rights from voters where email=? and password=?");
		pst2 = cn.prepareStatement("select * from candidates");
		pst3 = cn.prepareStatement("select * from candidates order by votes desc limit 2");
		pst4 = cn.prepareStatement("update voters set status='true' where id=?");
		pst5 = cn.prepareStatement("update candidates set votes=votes+1 where id=?");
		pst6 = cn.prepareStatement("select political_party,sum(votes) from candidates group by political_party order by sum(votes) desc");
	}

	public void cleanUp() throws SQLException
	{
		if(pst1 != null)
			pst1.close();
		if(pst2 != null)
			pst2.close();
		if(pst3 != null)
			pst3.close();
		if(pst4 != null)
			pst4.close();
		if(pst5 != null)
			pst5.close();
		if(pst6 != null)
			pst6.close();
		
		if(cn != null)
			cn.close();
	}
	
	@Override
	public Voters authenticateVoter(String em, String pass) throws Exception {
		//Voters v = null;
		pst1.setString(1, em);
		pst1.setString(2, pass);
		try(ResultSet rst = pst1.executeQuery())
		{
			if(rst.next())
				return new Voters(rst.getInt(1),em,rst.getBoolean(3),rst.getString(4));
		}
		return null;
	}

	@Override
	public List<Candidate> getCandidateList() throws Exception {
		List<Candidate> l1 = new ArrayList<Candidate>();
		try(ResultSet rst = pst2.executeQuery())
		{
			while(rst.next())
				l1.add(new Candidate(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getInt(4)));
		}
		return l1;
	}

	@Override
	public String incVotesUpdateStatus(int candidateId, int voterId) throws Exception {
		//String msg = "Voting Failed!!";
		pst4.setInt(1, voterId);
		pst5.setInt(1, candidateId);
		int rst2 = pst4.executeUpdate();
		int rst3 = pst5.executeUpdate();
		if(rst3 == 1 && rst2 == 1)
			return "Voted Successfully!";
		return null;
	}

	@Override
	public List<Candidate> getTopTwoCandidate() throws Exception {
		List<Candidate> l1 = new ArrayList<Candidate>();
		try(ResultSet rst = pst3.executeQuery())
		{
			while(rst.next())
				l1.add(new Candidate(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getInt(4)));
		}
		return l1;
	}

	@Override
	public List<Candidate> getVotesPartyWise() throws Exception {
		List<Candidate> l1 = new ArrayList<Candidate>();
		try(ResultSet rst = pst6.executeQuery())
		{
			while(rst.next())
				l1.add(new Candidate(rst.getString(1),rst.getInt(2)));
		}
		return l1;
	}
	
	

}
