package utils;

import java.sql.*;

public class DBUtils {
	private static Connection cn;

	// add a static method to ret DB conn
	public static Connection fetchConnection() throws ClassNotFoundException, SQLException {
		if (cn == null) {
			String url = "jdbc:mysql://localhost:3306/JavaJDBC?autoReconnect=true&useSSL=false";
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection(url,"root","root1234");
		}
		return cn;
	}
	//add a static method to nullify connection
	public static void resetConn()
	{
		System.out.println("resetting cn to null");
		cn=null;
	}
}
