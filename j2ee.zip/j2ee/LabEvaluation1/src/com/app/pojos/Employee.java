package com.app.pojos;
import java.time.LocalDate;
import javax.persistence.*;

@Entity
@Table(name = "employees")
public class Employee {

	private Integer id;
	private String name,email;
	private double salary;
	private LocalDate dob;
	private Department dept;
	public Employee() {
		super();
	}
	public Employee(String name, String email, double salary, LocalDate dob) {
		super();
		this.name = name;
		this.email = email;
		this.salary = salary;
		this.dob = dob;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(length = 20)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length = 20,unique = true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Column(name = "birth_date")
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	
	@ManyToOne
	@JoinColumn(name = "dept_id")
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", salary=" + salary + ", dob=" + dob
				+ "]";
	}
	
	
	
}
