package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.dao.IDepartmentDao;
import com.app.pojos.Department;

@Controller 
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	private IDepartmentDao dao;
	
	public DepartmentController() {
		System.out.println("in dept controller ctor..");
	}
	
	@GetMapping("/list")
	public String getDepartmentList(Model map)
	{
		List<Department> depts = dao.getDepartments();
		map.addAttribute("dept_list", depts);
		return "/dept/list";
	}
	
	
	
}
