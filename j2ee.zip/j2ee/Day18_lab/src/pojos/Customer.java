package pojos;

import java.sql.Date;

public class Customer {

	private int id;
	private String email,password;
	private double regAmt;
	private Date regDate;
	
	
	public Customer(int id, String email, String password, double regAmt, Date regDate) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.regAmt = regAmt;
		this.regDate = regDate;
	}


	public Customer(String email, String password, double regAmt, Date regDate) {
		super();
		this.email = email;
		this.password = password;
		this.regAmt = regAmt;
		this.regDate = regDate;
	}


	@Override
	public String toString() {
		return "Customer [id=" + id + ", email=" + email + ", password=" + password + ", regAmt=" + regAmt
				+ ", regDate=" + regDate + "]";
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public double getRegAmt() {
		return regAmt;
	}


	public void setRegAmt(double regAmt) {
		this.regAmt = regAmt;
	}


	public Date getRegDate() {
		return regDate;
	}


	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	
	
	
}
