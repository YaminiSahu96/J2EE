package exception;

public class CustomerHandlingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerHandlingException() {
		super();
	}
	
	public CustomerHandlingException(String errMsg)
	{
		super(errMsg);
	}
}
