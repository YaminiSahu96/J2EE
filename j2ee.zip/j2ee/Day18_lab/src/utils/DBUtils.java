package utils;

import java.sql.*;

public class DBUtils {

	public static Connection connectDB() throws ClassNotFoundException,SQLException
	{
		String url = "jdbc:mysql://localhost:3306/JavaJDBC";
		Class.forName("com.mysql.cj.jdbc.Driver");
		return DriverManager.getConnection(url,"root","root1234");
	}
	
}
