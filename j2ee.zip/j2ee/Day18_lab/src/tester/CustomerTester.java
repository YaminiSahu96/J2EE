package tester;

import java.sql.Date;
import java.util.Scanner;

import dao.CustomerDaoImpl;
import exception.CustomerHandlingException;
import pojos.Customer;

public class CustomerTester {

	public static void main(String[] args) {
		boolean exit = false;
		try(Scanner sc = new Scanner(System.in))
		{
			CustomerDaoImpl cdao = new CustomerDaoImpl();
			while(!exit)
			{
				System.out.println("*************Menu************");
				System.out.println("1.SignIn User\n"
						+ "2.SignUp User\n"
						+ "3.Exit");
				System.out.println("Enter Option: ");
				switch(sc.nextInt())
				{
				case 1:
					System.out.println("Enter Email and password: ");
					Customer c = cdao.signIn(sc.next(), sc.next());
					if(c == null)
						throw new CustomerHandlingException("No Customers found for this email/password!");
					System.out.println("Customer Logged In Successfully!");
					break;
				case 2:
					System.out.println("Enter Customer Details (Email,Password,Registration Amt,Registration Date): ");
					System.out.println(cdao.signUp(new Customer(sc.next(), sc.next(), sc.nextDouble(), Date.valueOf(sc.next()))));
					break;
				case 3:
					exit = true;
					cdao.cleanUp();
					break;
				default:
					System.out.println("Enter a valid option!");
					break;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
