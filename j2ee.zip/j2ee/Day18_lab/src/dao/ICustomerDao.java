package dao;

import pojos.Customer;

public interface ICustomerDao {

	Customer signIn(String email,String pass) throws Exception;
	
	String signUp(Customer c) throws Exception;
	
}
