package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static utils.DBUtils.*;
import pojos.Customer;

public class CustomerDaoImpl implements ICustomerDao {

	private Connection cn;
	private PreparedStatement pst1,pst2;
	
	public CustomerDaoImpl() throws ClassNotFoundException, SQLException 
	{	//in tester only one instance of this class
		cn = connectDB();
		pst1 = cn.prepareStatement("SELECT * FROM my_customers WHERE email=? AND password=?");
		pst2 = cn.prepareStatement("INSERT INTO my_customers VALUES (default,?,?,?,?)");
	}
	
	public void cleanUp() throws Exception
	{
		if(pst1 != null)
			pst1.close();
		if(pst2 != null)
			pst2.close();
		
		if(cn != null)
			cn.close();
		System.out.println("CustDao cleaned Up!");
	}
	
	@Override
	public Customer signIn(String email, String pass) throws Exception 
	{
		
		Customer c = null;
		pst1.setString(1, email);
		pst1.setString(2, pass);
		
		try(ResultSet rst = pst1.executeQuery())
		{
			if(rst.next())
				c = new Customer(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getDouble(4), rst.getDate(5)); 
		}
		
		return c;
	}

	@Override
	public String signUp(Customer c) throws Exception 
	{
		
		String msg = "Failed to Insert into my_customer table";
		pst2.setString(1, c.getEmail());
		pst2.setString(2, c.getPassword());
		pst2.setDouble(3, c.getRegAmt());
		pst2.setDate(4, c.getRegDate());
		
		int rst = pst2.executeUpdate();
		if(rst == 1)
			msg = "Customer Details Inserted Successfully!";
		
		return msg;
	}

}
