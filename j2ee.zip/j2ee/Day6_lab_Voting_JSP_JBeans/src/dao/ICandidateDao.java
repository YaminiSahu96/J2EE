package dao;

import java.util.List;

import pojos.Candidate;

public interface ICandidateDao {
	
	List<Candidate> getVotesPartyWise() throws Exception;
	
	List<Candidate> getCandidateList() throws Exception;
	
	String updateVotes(int canId) throws Exception;
	
}
