package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static utils.DBUtils.*;
import pojos.Candidate;

public class CandidateDaoImpl implements ICandidateDao {

	Connection cn;
	PreparedStatement pst2,pst5,pst6;
	
	public CandidateDaoImpl() throws Exception{
		cn = connectDB();
		pst2 = cn.prepareStatement("select * from candidates");
		pst5 = cn.prepareStatement("update candidates set votes=votes+1 where id=?");
		pst6 = cn.prepareStatement("select political_party,sum(votes) from candidates group by political_party order by sum(votes) desc");
		
	}
	
	public void cleanUp() throws SQLException
	{
		if(pst2 != null)
			pst2.close();
		if(pst5 != null)
			pst5.close();
		if(pst6 != null)
			pst6.close();
		
		if(cn != null)
			cn.close();
	}
	
	@Override
	public List<Candidate> getCandidateList() throws Exception {
		List<Candidate> l1 = new ArrayList<Candidate>();
		try(ResultSet rst = pst2.executeQuery())
		{
			while(rst.next())
				l1.add(new Candidate(rst.getInt(1),rst.getString(2),rst.getString(3),rst.getInt(4)));
		}
		return l1;
	}

	@Override
	public List<Candidate> getVotesPartyWise() throws Exception {
		List<Candidate> l1 = new ArrayList<Candidate>();
		try(ResultSet rst = pst6.executeQuery())
		{
			while(rst.next())
				l1.add(new Candidate(rst.getString(1),rst.getInt(2)));
		}
		return l1;
	}

	@Override
	public String updateVotes(int canId) throws Exception {
		pst5.setInt(1, canId);
		int rst3 = pst5.executeUpdate();
		if(rst3 == 1)
			return "Incremented Votes Successfully!!";
		return null;
	}

}
