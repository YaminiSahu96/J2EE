package dao;

import pojos.Voters;

public interface IVotingDao {

	Voters authenticateVoter(String em,String pass) throws Exception;
	
	String updateStatus(int voterId) throws Exception;
	
	String registerVoter(String email,String password) throws Exception;
}
