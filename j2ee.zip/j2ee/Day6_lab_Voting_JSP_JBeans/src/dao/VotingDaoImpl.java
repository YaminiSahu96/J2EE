package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.Voters;
import static utils.DBUtils.*;

public class VotingDaoImpl implements IVotingDao {

	Connection cn;
	PreparedStatement pst1,pst2,pst4;
	
	public VotingDaoImpl() throws ClassNotFoundException, SQLException 
	{
		cn = connectDB();
		pst1 = cn.prepareStatement("select id,email,status,admin_rights from voters where email=? and password=?");
		pst4 = cn.prepareStatement("update voters set status='true' where id=?");
		pst2 = cn.prepareStatement("insert into voters values(default,?,?,'false','voter')");
		}

	public void cleanUp() throws SQLException
	{
		if(pst1 != null)
			pst1.close();
		if(pst4 != null)
			pst4.close();
		if(pst2 != null)
			pst2.close();
		if(cn != null)
			cn.close();
	}
	
	@Override
	public Voters authenticateVoter(String em, String pass) throws Exception {
		pst1.setString(1, em);
		pst1.setString(2, pass);
		try(ResultSet rst = pst1.executeQuery())
		{
			if(rst.next())
				return new Voters(rst.getInt(1),em,rst.getBoolean(3),rst.getString(4));
		}
		return null;
	}

	

	@Override
	public String updateStatus(int voterId) throws Exception {
		pst4.setInt(1, voterId);
		
		int rst2 = pst4.executeUpdate();
		
		if( rst2 == 1)
			return "Voted Successfully!";
		return null;
	}

	@Override
	public String registerVoter(String email, String password) throws Exception {
		pst2.setString(1, email);
		pst2.setString(2, password);
		int rst = pst2.executeUpdate();
		if(rst == 1)
			return "Registration Successful!!";
		return null;
	}

	

	
	

}
