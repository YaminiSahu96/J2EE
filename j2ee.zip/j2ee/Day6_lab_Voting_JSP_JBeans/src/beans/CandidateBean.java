package beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import dao.CandidateDaoImpl;
import pojos.Candidate;

public class CandidateBean {

	private int canId;
	private CandidateDaoImpl dao;
	
	public void setCanId(int canId) {
		this.canId = canId;
	}


	public CandidateBean() throws Exception
	{
		dao = new CandidateDaoImpl();
	}
	
	public List<Candidate> getTopTwoCandidates() throws Exception
	{
		List<Candidate> candy = new ArrayList<>();
		List<Candidate> candidates = getCandidateList();
		
		Collections.sort(candidates, Collections.reverseOrder(new Comparator<Candidate>() {
		
			@Override
			public int compare(Candidate c1, Candidate c2)
			{
				return ((Integer)c1.getVotes()).compareTo(c2.getVotes());
			}
		}));
		
		
		candy.add(candidates.get(0));
		candy.add(candidates.get(1));
		return candy;
	}
	public List<Candidate> getVotesPartyWise() throws Exception
	{
		return dao.getVotesPartyWise();
	}
	
	public List<Candidate> getCandidateList() throws Exception
	{
		return dao.getCandidateList();
	}
	
	public String updateVotes() throws Exception
	{
		String msg = dao.updateVotes(canId);
		return (msg != null) ? msg : "unable to Increment votes";
	}
	
}
