package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CustomerDaoImpl cdao;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		System.out.println("In Init...Creating instance of CustomerDaoImpl...");
		try {
			cdao = new CustomerDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init of "+getClass().getName(),e);
		} 
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			cdao.cleanUp();
			System.out.println("Cleaned Up!");
		} catch (Exception e) {
			throw new RuntimeException("Err in clean up",e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String email = request.getParameter("em");
		String pass = request.getParameter("pass");
		Customer c=null;
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			if(!email.isEmpty() && !pass.isEmpty())
				c=cdao.signIn(email, pass);
			if(c == null)
				pw.print("<h3>No customer found!</h3><a href=\"login.html\">Retry</a>");
			else
				pw.print("<h3>Welcome "+email+" to Advanced Java</h3><h3>"+c.toString()+"</h3>");
			
		} catch (Exception e) 
		{
			throw new ServletException("exception in doGet of "+getClass().getName(),e);
		}
		
	}

}
