package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDaoImpl;
import dao.CustomerDaoImpl;
import pojos.Book;

/**
 * Servlet implementation class CartContentsServlet
 */
@WebServlet("/cart_content")
public class CartContentsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			BookDaoImpl bookDao = (BookDaoImpl) request.getAttribute("book_dao");	//request scope attributes
			List<Integer> shoppingCart = (List<Integer>) request.getAttribute("cart");
			if(shoppingCart.isEmpty())
				pw.write("<h4 align='center'>Cart is Empty!!</h4>");
			else {
				pw.write("Your Cart Contents<br>");
				double sum = 0;
				for(int i:shoppingCart)
				{
					Book b = bookDao.getBookDetails(i);
					pw.print(b+"<br>");
					sum += b.getPrice();
				}
				pw.write("Total Cart Price = "+sum+"<br>");
				
			}
			if(request.getAttribute("logout").equals("exit"))
			{
				//CustomerDaoImpl custDao = (CustomerDaoImpl) request.getAttribute("cust_dao");
				pw.write("<h4>Logged out successfully!!</h4>");
				//bookDao.cleanUp();	//Should only be called inside destroy() of main Servlet(here Login)
				//custDao.cleanUp();
			}else
			{
				pw.write("<a href='cat_select'>Back to Catagory</a></h4>");
			}
		}catch(Exception e)
		{
			throw new ServletException("err in doGet.."+getClass().getName(),e);
		}
	}

}
