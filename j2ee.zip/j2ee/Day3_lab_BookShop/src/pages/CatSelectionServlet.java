package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class CatSelectionServlet
 */
@WebServlet("/cat_select")
public class CatSelectionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			HttpSession hs = request.getSession();
			Customer c = (Customer) hs.getAttribute("cust_dtls");
			if(c != null)
			{
				BookDaoImpl bookDao = (BookDaoImpl) hs.getAttribute("book_dao");
				List<String> names = bookDao.getAllCategories();
				pw.print("<h4>Hello , "+c.getEmail()+"</h4>");
				pw.print("<h3 align=center>Category List </h3>");
				pw.print("<form action='category_books'>");
				pw.print("Choose a Category ");
				pw.print("<select name='cat'>");
				for(String s : names)
					pw.print("<option value="+s+">"+s+"</option>");
				pw.print("</select>");
				pw.print("<input type='submit' value='Choose'>");
				pw.print("<input type='submit' value='Show Cart' formaction='show_cart'><br>");
				pw.print("</form>");
				pw.print("<a href='log_out'>Check Out</a>");
			}else {
				pw.write("<h4>You are Not Logged In...<br><a href='login.html'>Retry Login</a></h4>");
			}
				
		}catch(Exception e)
		{
			throw new ServletException("err in doGet..."+getClass().getName(),e);
		}
		
	}

}
