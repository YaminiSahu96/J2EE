package pages;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddCartServlet
 */
@WebServlet("/add_to_cart")
public class AddCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String[] selectedBooks = request.getParameterValues("cat_id");
		
		HttpSession hs = request.getSession();
		List<Integer> shoppingCart=(List<Integer>)hs.getAttribute("cart");
		for(String i: selectedBooks)
			shoppingCart.add(Integer.parseInt(i));
		response.sendRedirect("cat_select");
		
	}

}
