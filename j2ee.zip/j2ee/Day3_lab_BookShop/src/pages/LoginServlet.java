package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookDaoImpl;
import dao.CustomerDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/validate")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private CustomerDaoImpl custDao;
	private BookDaoImpl bookDao;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		try {
			custDao = new CustomerDaoImpl();
			bookDao = new BookDaoImpl();
			System.out.println("In Init of "+getClass().getName());
		} catch (Exception e) {
			throw new ServletException("err in Init..."+getClass().getName(),e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			bookDao.cleanUp();
			custDao.cleanUp();
			System.out.println("In destroy of "+getClass().getName());
		}catch(Exception e)
		{
			throw new RuntimeException("eer in destroy..."+getClass().getName(),e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			Customer c = custDao.signIn(request.getParameter("em"), request.getParameter("pass"));
			HttpSession hs = request.getSession();
			
			if(c != null)
			{
				hs.setAttribute("cust_dtls", c);
				hs.setAttribute("cust_dao", custDao);
				hs.setAttribute("book_dao", bookDao);
				hs.setAttribute("cart", new ArrayList<Integer>());
				response.sendRedirect("cat_select");	//with cookie(JSESSIONID) and LOCATION(url-pattern)
			}
			else {
				pw.write("<h4>Invalid Credentials!!<br><a href='login.html'>Visit Again</a> OR <a href='reg_form.html'>Register As New User</a></h4>");
			}
				
		}
		catch(Exception e)
		{
			throw new ServletException("err in doPost..."+getClass().getName(),e);
		}
		
	}

}
