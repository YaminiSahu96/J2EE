package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class RegisterUserServlet
 */
@WebServlet("/register")
public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerDaoImpl custDao;
	
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		try {
			custDao = new CustomerDaoImpl();
			System.out.println("In Init of "+getClass().getName());
		} catch (Exception e) {
			throw new ServletException("err in Init..."+getClass().getName(),e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			custDao.cleanUp();
			System.out.println("In destroy of "+getClass().getName());
		}catch(Exception e)
		{
			throw new RuntimeException("eer in destroy..."+getClass().getName(),e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			String msg = custDao.signUp(new Customer(request.getParameter("mail"), request.getParameter("pass"), Double.parseDouble(request.getParameter("reg_amt")), Date.valueOf(request.getParameter("reg_date"))));
			if(msg != null)
			{
				pw.write("<h4>"+msg+" </h4>");
				pw.write("<a href='login.html'>Proceed to Login</a>");
			}
			else
				pw.write("Failed to Register! Please <a href='reg_form.html'>Retry</a>");
		}catch(Exception e)
		{
			throw new ServletException("err in doPost..."+getClass().getName(),e);
		}
	}

}
