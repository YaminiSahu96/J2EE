package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/log_out")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		try(PrintWriter pw = response.getWriter())
		{
			HttpSession hs = request.getSession();
			Customer c = (Customer) hs.getAttribute("cust_dtls");
			if(c != null)
			{
				BookDaoImpl bookDao = (BookDaoImpl) hs.getAttribute("book_dao");
				List<Integer> shoppingCart = (List<Integer>) hs.getAttribute("cart");
				request.setAttribute("book_dao", bookDao);	//request scope attributes
				request.setAttribute("cart", shoppingCart);
				request.setAttribute("logout", "exit");
				//RD--->include for Displaying Cart Contents
				RequestDispatcher rd = request.getRequestDispatcher("cart_content");
				pw.write("<h4 align='center'>Hello, "+c.getEmail()+"<br>");
				if(rd != null)
					rd.include(request, response);
				
				hs.invalidate();
			}else {
				pw.write("<h4>You are Not Logged In...<br><a href='login.html'>Retry Login</a></h4>");
			}
		}catch(Exception e)
		{
			throw new ServletException("err in doGet..."+getClass().getName(),e);
		}
		
	}

}
