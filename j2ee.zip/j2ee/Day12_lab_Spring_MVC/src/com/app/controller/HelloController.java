package com.app.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller		//Mandatory (Singleton and EAGER)
public class HelloController {

	public HelloController() {
		System.out.println("in hello ctor");
	}

	//request handling method
	@RequestMapping("/hi")
	public String test1()
	{
		System.out.println("in test1 method");
		return "/home";
	}
	
	@RequestMapping("/hi2")
	public ModelAndView test2()
	{
		System.out.println("in test2 method");
		return new ModelAndView("/home", "server_dt", LocalDateTime.now());
	}
	
}
