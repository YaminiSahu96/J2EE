package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WelcomeServlet
 */
//@WebServlet("/welcome")		//url-pattern --- key for map
public class WelcomeServlet extends HttpServlet {	//fully qualified class ---> value for map
	private static final long serialVersionUID = 1L;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {	// will be initialized(Only once) when first request came from first client
		System.out.println("Init Started..."+Thread.currentThread());
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("Destroying..."+Thread.currentThread());
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	//HttpServlet's service method is called by Web-Container and in-turn service method calls doGet
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In doGet..."+Thread.currentThread());
		//set response content type --  for client browser
		response.setContentType("text/html");// text/html--->Mime type
		try(PrintWriter pw = response.getWriter())
		{
			pw.print("<h4>Welcome to Servlets @"+LocalDateTime.now()+"</h4>");
		}
	}

}
