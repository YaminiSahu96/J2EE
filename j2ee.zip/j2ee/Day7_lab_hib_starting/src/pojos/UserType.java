package pojos;

public enum UserType {

	SILVER,GOLD,PLATINUM;
	
}
