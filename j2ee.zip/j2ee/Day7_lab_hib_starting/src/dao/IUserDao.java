package dao;

import pojos.User;

public interface IUserDao {

	//user Registration
	String registerUser(User u);
	
}
