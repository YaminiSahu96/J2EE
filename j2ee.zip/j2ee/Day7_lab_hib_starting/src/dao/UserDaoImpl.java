package dao;

import pojos.User;
import static utils.HibernateUtils.*;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class UserDaoImpl implements IUserDao{

	@Override
	public String registerUser(User u) {
		// Get session from session factory
		Session hs = getSf().openSession();
		//begin a txn
		Transaction tx= hs.beginTransaction();
		try {
			hs.save(u);
			tx.commit();						//last step of try always
		}
		catch(HibernateException e)
		{
			if(tx != null)
				tx.rollback();
			// rethrow the exec to the caller
			throw e;
		}
		finally {
			//close session -- rets pooled out DB connection to the conn pool
			hs.close();
		}
		return "User Registration Success!! --> User ID:"+u.getUserId();
	}

}
