package tester;

import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;
import pojos.User;
import pojos.UserType;

public class RegisterUser {

	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		try (SessionFactory sf = getSf(); Scanner sc = new Scanner(System.in)) {
			System.out.println("hibernate booted....");
			System.out.println("Enter User Details(name, email, password, role, confirmPassword, regAmount,"
					+ "			 regDate, userType):");
			User u = new User(sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.nextDouble(),
					sdf.parse(sc.next()), UserType.valueOf(sc.next()));
			UserDaoImpl uDao = new UserDaoImpl();
			System.out.println(uDao.registerUser(u));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
